Link para a apresentação na internet:

https://penasta.github.io/presentations/apresentacao.html

Caso queira visualizar em máquina local:
arquivo: apresentação.html

OBS: O arquivo tem dependências para funcionar (a pasta apresentacao_files; inclusa nesse zipado. Basta não deleta-la).



Versão PDF:
apresentacao.pdf

Caso queira renderizar a versão pdf:
apresentacao.rmd



Caso queira somente os códigos:
códigos.r



CASO QUEIRA RENDERIZAR O HTML:
- ter o Quarto instalado no computador. Confira:
https://quarto.org/docs/get-started/

- Ter também R, Rstudio instalados. Os pacotes utilizados em R são automaticamente instalados, caso necessário, na renderização;

- Python versão 3+
É necessário instalar os pacotes python: pandas, numpy, sklearn. Para instalar, digite no terminal (com Python e pip instalados):

pip install pandas
pip install numpy
pip install sklearn


Após isso, abrir o arquivo apresentacao.qmd no Rstudio, e clicar em 'Render'.

Qualquer dúvida, envie email para Bruno:
150167636@aluno.unb.br